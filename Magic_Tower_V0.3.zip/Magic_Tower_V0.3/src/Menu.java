import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;
import java.lang.reflect.Method;

public class Menu {
	private Element rootElement;
	private final GameData gameData;
	private GameControl gameControl;
	private final GUI gui;

	public Menu(GameData gameData, GameControl gameControl, GUI gui) {
		this.gameData = gameData;
		this.gameControl = gameControl;
		this.gui = gui;
	}

	public void enterMenu() {
		menuOperation(rootElement);
	}

	public void loadMenu(String filePath) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new File(filePath));
			document.getDocumentElement().normalize();
			rootElement = document.getDocumentElement();
			removeTextNodes(rootElement);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void removeTextNodes(Node node) {
		NodeList childNodes = node.getChildNodes();
		for (int i = 0; i < childNodes.getLength(); i++) {
			Node child = childNodes.item(i);
			if (child.getNodeType() == Node.TEXT_NODE) {
				String textContent = child.getTextContent().trim();
				if (textContent.isEmpty()) {
					node.removeChild(child);
					i--;
				}
			} else if (child.getNodeType() == Node.ELEMENT_NODE) {
				removeTextNodes(child);
			}
		}
	}

	private void displayMenu(Element element) {
		gui.clearScreen();
		gui.printMessage("****" + element.getAttribute("title") + "****");
		NodeList childElements = element.getChildNodes();
		for (int i = 0; i < childElements.getLength(); i++) {
			Node child = childElements.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				Element childElement = (Element) child;
				gui.printMessage((i + 1) + ". " + childElement.getAttribute("title"));
			}
		}
		gui.printMessage("0. Back to Upper Menu");
		gui.refreshGUI();
	}

	private void menuOperation(Element element) {
		while (true) {
			displayMenu(element);
			gui.printMessage("Choose an option: ");
			String input = GUI.keyboardInput.nextLine();
			int inputNum;
			try {
				inputNum = Integer.parseInt(input);
			} catch (NumberFormatException e) {
				gui.printMessage("Invalid Input. Please enter a number.");
				continue;
			}
			if (inputNum == 0) {
				return;
			} else {
				NodeList childElements = element.getChildNodes();
				if (inputNum > 0 && inputNum <= childElements.getLength()) {
					Node selectedNode = childElements.item(inputNum - 1);
					if (selectedNode.getNodeType() == Node.ELEMENT_NODE) {
						Element selectedElement = (Element) selectedNode;
						String isFunction = selectedElement.getAttribute("isFunction");
						if ("No".equalsIgnoreCase(isFunction)) {
							menuOperation(selectedElement);
						} else {
							callMethod(selectedElement.getAttribute("method"));
						}
					}
				} else {
					gui.printMessage("Invalid Input. Option out of range.");
				}
			}
		}
	}

	private void callMethod(String methodName) {
		try {
			Method method = getClass().getMethod(methodName);
			method.invoke(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void restartGame() {
		gameControl.restartGame();
	}

	public void quitGame() {
		System.exit(0);
	}

	public void saveGame() {
		try {
			gameControl.gameData.saveState();
			gui.printMessage("Game Saved to Game.ser");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void loadGame() {
		try {
			gameControl.gameData.restoreState();
			gui.printMessage("Game Loaded from Game.ser");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void revivePlayer() {
		if (gameData.getSavedState() != null) {
			gameData.restoreState();
			gameData.heroHealth = 105; // 或者设置为其他合适的数值
			gui.printMessage("You have been revived!");
			gui.refreshGUI(); // 确保界面刷新以反映变化
		} else {
			gui.printMessage("No previous state to restore.");
		}
	}

	public void setGameControl(GameControl gameControl) {
		this.gameControl = gameControl;
	}
}