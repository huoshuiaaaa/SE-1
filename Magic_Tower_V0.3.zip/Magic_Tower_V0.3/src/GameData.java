import java.io.Serializable;

public class GameData implements Serializable {
	public int keysCollected;
	int L, H, W, currentLevel = 0, pX = 3, pY = 3, heroHealth = 105, keyNum;
	int[][][] map;
	private transient GameData savedState;

	public void saveMapFromFile(String filePath) {
		try (var in = new java.util.Scanner(new java.io.File(filePath))) {
			this.L = in.nextInt();
			this.H = in.nextInt();
			this.W = in.nextInt();
			this.map = new int[this.L][this.H][this.W];

			for (int i = 0; i < this.L; ++i) {
				for (int j = 0; j < this.H; ++j) {
					for (int k = 0; k < this.W; ++k) {
						this.map[i][j][k] = in.nextInt();
						// 确保药水的值是7，骷髅兵的值是负数
					}
				}
			}
		} catch (java.io.IOException e) {
			System.out.println("Error with files:" + e.toString());
		}
	}
	public int potionsCollected = 0; // 添加这个字段来记录玩家持有的药水数量
	public void printMap() {
		char[] C = new char[]{'W', '_', 'K', 'D', 'S', 'E', 'H'};
		for (int j = 0; j < this.H; ++j) {
			for (int k = 0; k < this.W; ++k) {
				if (this.map[this.currentLevel][j][k] < 0) {
					System.out.print("M ");
				} else if (this.map[this.currentLevel][j][k] > 10) {
					System.out.print("P ");
				} else {
					System.out.print(C[this.map[this.currentLevel][j][k]] + " ");
				}
			}
			System.out.print("\n\n");
		}
		System.out.print("Health:" + this.heroHealth + "  KeyNum:" + this.keyNum + "  Menu:press 0\n");
	}

	public void reset() {
		this.currentLevel = 0;
		this.keyNum = 0;
		this.heroHealth = 105;
		this.pX = 3;
		this.pY = 3;
		saveMapFromFile("map.txt");
	}

	public void saveState() {
		this.savedState = new GameData();
		copyFields(this, this.savedState);
	}

	public void restoreState() {
		if (this.savedState != null) {
			copyFields(this.savedState, this);
			this.savedState = null;
		}
	}

	private void copyFields(GameData source, GameData target) {
		try {
			Class<?> clazz = this.getClass();
			java.lang.reflect.Field[] fields = clazz.getDeclaredFields();
			for (java.lang.reflect.Field field : fields) {
				if (!field.getName().equals("savedState")) {
					field.setAccessible(true);
					Object value = field.get(source);
					field.set(target, value);
				}
			}
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}

	public GameData getSavedState() {
		return this.savedState;
	}

	public void setSavedState(GameData state) {
		this.savedState = state;
	}
}