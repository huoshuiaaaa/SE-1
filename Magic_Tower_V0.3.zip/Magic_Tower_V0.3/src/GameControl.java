import javax.swing.JOptionPane;

public class GameControl {
	final GameData gameData;
	private final Menu menu;
	private final GUI gui;

	public GameControl(GameData gameData, Menu menu, GUI gui) {
		this.gameData = gameData;
		this.menu = menu;
		this.gui = gui;
	}

	public void restartGame() {
		gameData.reset();
		JOptionPane.showMessageDialog(gui.getFrame(), "Game Restarted!!");
		gui.refreshGUI();
	}

	public void gameStart() {
		// Start the game loop (if necessary)
		gui.getFrame().addKeyListener(new java.awt.event.KeyAdapter() {
			@Override
			public void keyPressed(java.awt.event.KeyEvent evt) {
				char c = evt.getKeyChar();
				if ("asdw".indexOf(c) >= 0) {
					handleInput(c);
					gui.refreshGUI();
				}
			}
		});
	}

	public void handleInput(char inC) {
		int tX = gameData.pX;
		int tY = gameData.pY;

		switch (inC) {
			case 'a': tY--; break; // Move left
			case 's': tX++; break; // Move down
			case 'd': tY++; break; // Move right
			case 'w': tX--; break; // Move up
		}

		// Check for valid move and interact with map elements
		if (isValidMove(tX, tY)) {
			int targetTile = gameData.map[gameData.currentLevel][tX][tY];
			switch (targetTile) {
				case 1: // Floor
					moveHero(tX, tY);
					break;
				case 2: // Key
					collectKey(tX, tY);
					break;
				case 3: // Door
					openDoor(tX, tY);
					break;
				case 4: // Stair
					goToNextLevel();
					break;
				case 5: // Exit
					winGame();
					break;
				case 7: // Potion
					collectPotion(tX, tY);
					break;
				default:
					if (targetTile < 0) { // Monster or other negative value tiles
						combatOrInteract(tX, tY);
					} else {
						// Handle any other tile types here if necessary
						moveHero(tX, tY);
					}
					break;
			}
		}
	}

	private void collectPotion(int x, int y) {
		// 增加玩家的生命值或其他效果
		gameData.heroHealth += 20; // 假设药水恢复20点生命值
		if (gameData.heroHealth > 105) { // 假设最大生命值为105
			gameData.heroHealth = 105;
		}
		gameData.potionsCollected++;
		gameData.map[gameData.currentLevel][x][y] = 1; // Change potion tile to floor
		moveHero(x, y);
		gui.printMessage("Potion collected! Health increased by 20.");
	}

	private boolean isValidMove(int x, int y) {
		return x >= 0 && x < gameData.H && y >= 0 && y < gameData.W
				&& gameData.map[gameData.currentLevel][x][y] != 0; // Only disallow moving into walls (assumed to be 0)
	}

	private void moveHero(int tX, int tY) {
		gameData.map[gameData.currentLevel][gameData.pX][gameData.pY] = 1; // Reset previous position to floor
		gameData.map[gameData.currentLevel][tX][tY] = 6; // Set new hero position
		gameData.pX = tX;
		gameData.pY = tY;
	}

	private void collectKey(int x, int y) {
		// Add key collection logic here
		gameData.keysCollected++;
		gameData.map[gameData.currentLevel][x][y] = 1; // Change key tile to floor
		moveHero(x, y);
		gui.printMessage("Key collected!");
	}

	private void openDoor(int x, int y) {
		if (gameData.keysCollected > 0) {
			gameData.keysCollected--;
			gameData.map[gameData.currentLevel][x][y] = 1; // Change door tile to floor
			moveHero(x, y);
			gui.printMessage("Door opened!");
		} else {
			gui.printMessage("You need a key to open this door.");
		}
	}

	private void goToNextLevel() {
		if (gameData.currentLevel < gameData.L - 1) {
			gameData.currentLevel++;
			gui.printMessage("Moved to next level!");
			gui.refreshGUI();
		} else {
			gui.printMessage("Congratulations! You've reached the last level.");
		}
	}

	private void winGame() {
		JOptionPane.showMessageDialog(gui.getFrame(), "Congratulations! You won the game!!", "Victory", JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
	}

	private void combatOrInteract(int x, int y) {
		int monsterHealth = gameData.map[gameData.currentLevel][x][y];

		// 假设骷髅兵的健康值为负数，因此需要取绝对值
		int absMonsterHealth = Math.abs(monsterHealth);

		if (absMonsterHealth + gameData.heroHealth <= 0) {
			// 如果玩家和怪物的总生命值小于等于0，则玩家被击败
			gameData.saveState();

			int choice = JOptionPane.showConfirmDialog(gui.getFrame(), "You have been defeated by the Skeleton. Do you want to revive?", "Defeat", JOptionPane.YES_NO_OPTION);

			if (choice == JOptionPane.YES_OPTION) {
				menu.revivePlayer(); // 调用 Menu 中的复活方法
			} else {
				System.exit(0);
			}
		} else {
			// 否则，减少玩家的生命值并移除骷髅兵
			gameData.heroHealth -= absMonsterHealth;
			gameData.map[gameData.currentLevel][x][y] = 1; // Change monster tile to floor
			moveHero(x, y);
			gui.printMessage("You fought a Skeleton! Health decreased by " + absMonsterHealth + ".");
		}
	}
}