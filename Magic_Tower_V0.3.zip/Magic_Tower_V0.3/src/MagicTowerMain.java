public class MagicTowerMain {
	public static void main(String[] args) {
		GameData gameData = new GameData();
		try {
			gameData.saveMapFromFile("Map.in");
			gameData.printMap();
		} catch (Exception e) {
			System.out.println("Failed to load map: " + e.getMessage());
			return;
		}

		GUI gui = new GUI(gameData, null, null); // 创建 GUI 实例，暂时传入 null
		Menu menu = new Menu(gameData, null, gui); // 创建 Menu 实例，暂时传入 null

		// 初始化 GameControl 并将其引用传递给 Menu 和 GUI
		GameControl gameControl = new GameControl(gameData, menu, gui);
		menu.setGameControl(gameControl); // 设置 Menu 的 GameControl 引用
		gui.setGameControl(gameControl);  // 设置 GUI 的 GameControl 引用

		menu.loadMenu("Menu.XML");
		gameControl.gameStart();
	}
}