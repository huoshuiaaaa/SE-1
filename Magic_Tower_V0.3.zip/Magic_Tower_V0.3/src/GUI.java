import javax.swing.*;
import java.awt.*;

public class GUI {

	private final GameData gameData;
	private final Menu menu;
	private GameControl gameControl;
	private JFrame frame;
	private JLabel[][] labels;
	private JTextArea messageArea;
	public static java.util.Scanner keyboardInput = new java.util.Scanner(System.in);

	public GUI(GameData gameData, Menu menu, GameControl gameControl) {
		this.gameData = gameData;
		this.menu = menu;
		setGameControl(gameControl);
		this.gameControl = gameControl;
		initializeGUI();
		refreshGUI();
	}

	private void initializeGUI() {
		frame = new JFrame("Magic Tower");
		labels = new JLabel[gameData.H][gameData.W];

		for (int i = 0; i < gameData.H; ++i) {
			for (int j = 0; j < gameData.W; ++j) {
				labels[i][j] = new JLabel();
				labels[i][j].setBounds(j * 100, i * 100, 100, 100);
				frame.add(labels[i][j]);
			}
		}

		JButton upButton = new JButton("↑");
		JButton downButton = new JButton("↓");
		JButton leftButton = new JButton("←");
		JButton rightButton = new JButton("→");

		upButton.setBounds(gameData.W * 100 + 40, 100, 80, 40);
		downButton.setBounds(gameData.W * 100 + 40, 200, 80, 40);
		leftButton.setBounds(gameData.W * 100 + 10, 150, 80, 40);
		rightButton.setBounds(gameData.W * 100 + 90, 150, 80, 40);

		upButton.addActionListener(e -> {
			if (gameControl != null) {
				gameControl.handleInput('w');
				refreshGUI();
			}
		});
		downButton.addActionListener(e -> {
			if (gameControl != null) {
				gameControl.handleInput('s');
				refreshGUI();
			}
		});
		leftButton.addActionListener(e -> {
			if (gameControl != null) {
				gameControl.handleInput('a');
				refreshGUI();
			}
		});
		rightButton.addActionListener(e -> {
			if (gameControl != null) {
				gameControl.handleInput('d');
				refreshGUI();
			}
		});

		frame.add(upButton);
		frame.add(downButton);
		frame.add(leftButton);
		frame.add(rightButton);

		messageArea = new JTextArea(10, 40);
		messageArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(messageArea);
		scrollPane.setBounds(gameData.W * 100 + 20, 300, 200, 200);
		frame.add(scrollPane);

		frame.setSize(gameData.H * 100 + 250, gameData.W * 100 + 350);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void printMessage(String message) {
		messageArea.append(message + "\n");
		messageArea.setCaretPosition(messageArea.getDocument().getLength());
	}

	public void clearScreen() {
		messageArea.setText("");
	}

	public void refreshGUI() {
		for (int i = 0; i < gameData.H; ++i) {
			for (int j = 0; j < gameData.W; ++j) {
				Image scaledImage = chooseImage(gameData.map[gameData.currentLevel][i][j]);
				labels[i][j].setIcon(new ImageIcon(scaledImage));
			}
		}
		printStatus(); // 打印玩家状态
	}

	private void printStatus() {
		messageArea.append(String.format("Health: %d  Potions: %d\n", gameData.heroHealth, gameData.potionsCollected));
		messageArea.setCaretPosition(messageArea.getDocument().getLength());
	}
	private static Image chooseImage(int index) {
		ImageIcon[] icons = new ImageIcon[]{
				new ImageIcon("Wall.jpg"),
				new ImageIcon("Floor.jpg"),
				new ImageIcon("Key.jpg"),
				new ImageIcon("Door.jpg"),
				new ImageIcon("Stair.jpg"),
				new ImageIcon("Exit.jpg"),
				new ImageIcon("Hero.jpg"),
				new ImageIcon("Potion.jpg"),
				new ImageIcon("Monster.jpg")
		};
		Image scaledImage;
		if (index > 10) {
			scaledImage = icons[7].getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		} else if (index < 0) {
			scaledImage = icons[8].getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		} else {
			scaledImage = icons[index].getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		}
		return scaledImage;
	}

	public JFrame getFrame() {
		return frame;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setGameControl(GameControl gameControl) {
		this.gameControl = gameControl;
	}
}